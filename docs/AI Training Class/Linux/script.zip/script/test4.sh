#!/bin/bash
for i in {1..5}
do
  echo "迴圈次數：$i"
done

