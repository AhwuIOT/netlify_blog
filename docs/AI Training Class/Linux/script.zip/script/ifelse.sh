#!/bin/bash
if [ $1 -gt 100 ]
then
  echo "$1 是大於 100 的數字"
else
  echo "$1 不大於 100"
fi

