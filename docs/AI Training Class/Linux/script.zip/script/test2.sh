#!/bin/bash
echo "腳本名稱：$0"
echo "第一個參數：$1"
echo "第二個參數：$2"
echo "所有參數：$@"
echo "參數總數：$#"

